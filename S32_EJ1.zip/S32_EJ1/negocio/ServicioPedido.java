package S32_EJ1.negocio;

import S32_EJ1.modelo.Producto;
import S32_EJ1.modelo.ResumenPedido;

public class ServicioPedido {

    private static final int MAX_UNIDADES = 10;
    private static final double GASTOS_ENVIO = 4.95;
    private static final double ENVIO_GRATIS_DESDE = 30.0;
    private static final int AVISO_ULTIMAS =3;

    private ServicioCatalogo catalogo;

    public ServicioPedido(ServicioCatalogo catalogo) {
        this.catalogo = catalogo;
    }

    public boolean cantidadValida(int cantidad) {
        return cantidad >= 1 && cantidad <= MAX_UNIDADES;
    }

    public boolean disponible(Producto p) {
        return p.getStock() > 0;
    }

    public boolean ultimasUnidades(Producto p) {
        return p.getStock()> 0 && p.getStock() <= AVISO_ULTIMAS;
    }

    public boolean hayStock (Producto p, int cantidad) {
        return cantidad <= p.getStock();
    }

    public ResumenPedido calcular(Producto p, int cantidad) {
        double precioUnidad = catalogo.precioFinal(p);
        double subtotal = Math.round(precioUnidad * cantidad * 100) / 100.0;
        double envio = GASTOS_ENVIO;
        if (subtotal >= ENVIO_GRATIS_DESDE) {
            envio = 0;
        }
        double total = Math.round((subtotal + envio) * 100) / 100.0;
        return new ResumenPedido(p.getNombre(), cantidad, precioUnidad, subtotal, envio, total);
    }


}
