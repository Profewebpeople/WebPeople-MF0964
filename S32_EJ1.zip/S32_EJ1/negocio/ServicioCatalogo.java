package S32_EJ1.negocio;

import S32_EJ1.datos.RepositorioProductos;
import S32_EJ1.modelo.Producto;

import java.util.ArrayList;
import java.util.List;

public class ServicioCatalogo {

    private static final boolean BLACK_FRIDAY = true;
    private static final double DESCUENTO = 0.20;

    private RepositorioProductos repositorio;

    public ServicioCatalogo(RepositorioProductos repositorio) {
        this.repositorio = repositorio;
    }

    public Producto buscar(String nombre) {
        String limpio = nombre.trim();
        if (limpio.isEmpty()) {
            return null;
        }
        return repositorio.buscarPorNombre(limpio);
    }

    public List<Producto> listar() {
        return repositorio.todos();
    }

    public List<Producto> buscarPorTexto(String texto) {
        String buscado = texto.trim().toLowerCase();
        List<Producto> resultados = new ArrayList<>();
        for(Producto p : repositorio.todos()){
            if(p.getNombre().toLowerCase().contains(buscado)){
                resultados.add(p);
            }
        }return resultados;
    }

    public double precioFinal(Producto p) {
        if (BLACK_FRIDAY) {
            return Math.round(p.getPrecio() * (1 - DESCUENTO) * 100) / 100.0;
        }
        return p.getPrecio();
    }
}
