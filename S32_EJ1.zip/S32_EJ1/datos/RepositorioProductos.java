package S32_EJ1.datos;

import S32_EJ1.modelo.Producto;
import java.util.List;

public interface RepositorioProductos {
    Producto buscarPorNombre(String nombre);

    List<Producto> todos();
}
