package S32_EJ1.datos;

import S32_EJ1.modelo.Producto;
import java.util.List;
public class RepositorioMemoria implements RepositorioProductos{

    private List<Producto> productos = List.of(
            new Producto("Taza", 8.49,25 ),
            new Producto("Camiseta",15.99,3),
            new Producto("Gorra",10.05,0)
            );

    @Override
    public Producto buscarPorNombre(String nombre) {
        for (Producto p : productos) {
            if(p.getNombre().equalsIgnoreCase(nombre)){
                return p;
            }
        }return null;
    }

    @Override
    public List<Producto>todos(){
        return productos;
    }

}
