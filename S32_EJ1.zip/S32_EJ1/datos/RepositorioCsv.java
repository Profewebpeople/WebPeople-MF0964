package S32_EJ1.datos;
import S32_EJ1.modelo.Producto;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;



public class RepositorioCsv implements RepositorioProductos {

    private List<Producto> productos= new ArrayList<>();

    public RepositorioCsv(String fichero) throws IOException {
        List<String> lineas = Files.readAllLines(Path.of(fichero), StandardCharsets.UTF_8);
        //bucle de recorrido por las lineas del fichero
        for(int i=1;i<lineas.size();i++){
            String[]partes=lineas.get(i).split(";");
            String nombre = partes[0];
            double precio =Double.parseDouble(partes[1]);
            int stock = Integer.parseInt(partes[2]);
            productos.add(new Producto(nombre,precio,stock));
        }

        System.out.println("[Repositorio] La lista de productos es: "+productos.size()+"productos leídos de "+fichero);
    }

    @Override
    public Producto buscarPorNombre(String nombre) {
        for(Producto p: productos){
            if(p.getNombre().equalsIgnoreCase(nombre)) {
                return p;
            }
        } return null;
    }

    @Override
    public List<Producto>todos(){
        return productos;
    }


}


















