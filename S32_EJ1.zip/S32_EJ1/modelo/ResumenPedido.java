package S32_EJ1.modelo;


public class ResumenPedido {

    private String producto;
    private int cantidad;
    private double precioUnidad;
    private double subtotal;
    private double gastosEnvio;
    private double total;

    public ResumenPedido(String producto,int cantidad,double precioUnidad, double subtotal,double gastosEnvio,double total) {
        this.producto = producto;
        this.cantidad = cantidad;
        this.precioUnidad = precioUnidad;
        this.subtotal = subtotal;
        this.gastosEnvio = gastosEnvio;
        this.total = total;
    }
    public String getProducto() {
        return producto;
    }
    public int getCantidad() {
        return cantidad;
    }
    public double getPrecioUnidad() {
        return precioUnidad;
    }
    public double getSubtotal() {
        return subtotal;
    }
    public double getGastosEnvio() {
        return gastosEnvio;
    }
    public double getTotal() {
        return total;
    }
}
