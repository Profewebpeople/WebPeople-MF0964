package S32_EJ1.presentacion;

import com.sun.net.httpserver.HttpServer;
import S32_EJ1.datos.RepositorioCsv;
import S32_EJ1.datos.RepositorioProductos;
import S32_EJ1.negocio.ServicioCatalogo;
import S32_EJ1.negocio.ServicioPedido;

import java.io.IOException;
import java.net.InetSocketAddress;


public class ServidorTienda {

    public static void main(String[] args) throws IOException {
        RepositorioProductos repositorio = new RepositorioCsv("productos.csv");

        ServicioCatalogo servicio = new ServicioCatalogo(repositorio);

        ServicioPedido pedidos = new ServicioPedido(servicio);

        HttpServer servidor = HttpServer.create(new InetSocketAddress(8081), 0);
        servidor.createContext("/inicio", new ControladorInicio(servicio, pedidos));
        servidor.createContext("/producto/", new ControladorProducto(servicio, pedidos));
        servidor.createContext("/comprar/",new ControladorCompra(servicio, pedidos));
        servidor.createContext("/buscar", new ControladorBusqueda(servicio));
        servidor.start();

        System.out.println("Servidor Iniciado, Tienda online funcionado");
        System.out.println("http://localhost:8081/inicio");
    }
}
