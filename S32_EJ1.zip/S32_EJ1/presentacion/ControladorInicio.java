package S32_EJ1.presentacion;
import S32_EJ1.negocio.ServicioPedido;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import S32_EJ1.negocio.ServicioCatalogo;
import S32_EJ1.modelo.Producto;
import java.io.IOException;


public class ControladorInicio implements HttpHandler {

    private ServicioCatalogo servicio;
    private ServicioPedido pedidos;
    public ControladorInicio(ServicioCatalogo servicio, ServicioPedido pedidos) {
        this.servicio = servicio;
        this.pedidos = pedidos;
    }

    @Override
    public void handle(HttpExchange intercambio) throws IOException{
//        String lista="";
//        for(Producto p : servicio.listar()){
//            lista += "<li><a href=\"/producto/" + p.getNombre() + "\">" + p.getNombre() + "</a> · "
//                    + Plantilla.euros(servicio.precioFinal(p)) + "</li>";
//        }
//        String contenido = "<h1>Ofertas de Black Friday</h1><ul>" + lista + "</ul>";
//        EnvioHttp.enviarHtml(intercambio, 200, Plantilla.pagina("Inicio", contenido));

        String filas = "";
        for( Producto p: servicio.listar()){
            String estado = "Disponible" ;
            if(!pedidos.disponible(p)){
                estado = "Agotado";
            }else if (pedidos.ultimasUnidades(p)){
                estado = "¡ULTIMAS UNIDADES!";
            }
            filas
                    += "<t>"
                    + "<td> <a href=\"/producto/"+p.getNombre()+"\">"+p.getNombre()+"</a> </td>"
                    +"<td><s>"+Plantilla.euros(p.getPrecio())+"</s></td>"
                    +"<td><b>"+Plantilla.euros(servicio.precioFinal(p))+"</b></td>"
                    +"<td>"+estado+"</td>"
                    +"</tr>";

        }
        String contenido = "<h1>Ofertas de Black Friday</h1>"
                +"<table>"
                +"<tr><th>Producto</th><th>Antes</th> <th>Black Friday</th> <th>Disponibilidad</th></tr>"
                +filas
                +"</table>";
        EnvioHttp.enviarHtml(intercambio, 200, Plantilla.pagina("Inicio", contenido));

    }

}





























