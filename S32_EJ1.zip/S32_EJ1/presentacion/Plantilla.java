package S32_EJ1.presentacion;

public class Plantilla {
    public static   String pagina(String titulo, String contenido){
        return "<!DOCTYPE html><html><head><meta charset=\"UTF-8\">"
                + "<title>" + titulo + " | TiendaOnline</title></head><body>"
                +"<style>table{border-collapse: collapse: th,td{border: 1px solid #000; padding: 6px 10px}</style>"
                + "<header><a href=\"/inicio\">TiendaOnline</a>"
                + "<form action=\"/buscar\" method=\"get\">"
                + "<label for=\"q\">Buscar: </label>"
                + "<input type=\"search\" id=\"q\" name=\"q\"  placeholder=\"taza, gorra...\"required>"
                +"<button> Buscar </button> </form> </header>"
                + "<main>" + contenido + "</main>"
                + "<footer>Envíos a toda España</footer>"
                + "</body></html>";

    }
    public static String euros(double importe) {
        long centimos = Math.round(importe * 100);
        long euros = centimos / 100;
        long resto = centimos % 100;
        if (resto < 10) {
            return euros + ",0" + resto + " €";
        }
        return euros + "," + resto + " €";
    }

}
