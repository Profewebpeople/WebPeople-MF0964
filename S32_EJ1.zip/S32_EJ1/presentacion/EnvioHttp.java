package S32_EJ1.presentacion;
import com.sun.net.httpserver.HttpExchange;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;


public class EnvioHttp {

    public static void enviarHtml(HttpExchange intercambio, int codigo, String html) throws IOException {
        byte[] bytes = html.getBytes(StandardCharsets.UTF_8);
        intercambio.getResponseHeaders().set("Content-Type", "text/html; charset=UTF-8");
        intercambio.sendResponseHeaders(codigo, bytes.length);
        OutputStream salida = intercambio.getResponseBody();
        salida.write(bytes);
        salida.close();
        System.out.println("[EnvioHttp] enviando html" +intercambio.getRequestURI().getPath()+"->"+codigo);
    }
}
