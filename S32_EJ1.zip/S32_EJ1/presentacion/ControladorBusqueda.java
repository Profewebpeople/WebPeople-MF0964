package S32_EJ1.presentacion;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import S32_EJ1.modelo.Producto;
import S32_EJ1.negocio.ServicioCatalogo;
import java.io.IOException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.List;

public class ControladorBusqueda implements HttpHandler {

    private ServicioCatalogo servicio;

    public ControladorBusqueda(ServicioCatalogo servicio) {
        this.servicio = servicio;
    }


    @Override
    public void handle(HttpExchange intercambio) throws IOException {
        String consulta = intercambio.getRequestURI().getRawQuery();
        String texto = URLDecoder.decode(consulta.split("=")[1],  StandardCharsets.UTF_8);

        List<Producto> resultados = servicio.buscarPorTexto(texto);
        String contenido = "<h1> Resultados para [" + texto + "]</h1>";
        if(resultados.isEmpty()) {
            contenido += "<p> No hay productos que coincidan.</p>";
        }else {
            contenido += "<p> " + resultados.size() + " producto(s) encontrado(s):</p><ul>";
            for(Producto p : resultados) {
                contenido += "<li><a href=\"/producto/"+p.getNombre()+"\">"+p.getNombre()+"</a> ·"
                        +Plantilla.euros(servicio.precioFinal(p))+"</li>";
            }contenido += "</ul>";
        }

        EnvioHttp.enviarHtml(intercambio,200, Plantilla.pagina("Buscar", contenido));

    }

}


















