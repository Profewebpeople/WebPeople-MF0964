package S32_EJ1.presentacion;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import S32_EJ1.modelo.Producto;
import S32_EJ1.modelo.ResumenPedido;
import java.io.IOException;
import S32_EJ1.negocio.ServicioCatalogo;
import S32_EJ1.negocio.ServicioPedido;

public class ControladorCompra implements HttpHandler {

    private ServicioCatalogo catalogo;
    private ServicioPedido pedidos;

    public ControladorCompra(ServicioCatalogo catalogo, ServicioPedido pedidos) {
        this.catalogo = catalogo;
        this.pedidos = pedidos;
    }

    @Override
    public void handle(HttpExchange intercambio) throws IOException {
        String ruta = intercambio.getRequestURI().getPath();
        String nombre = ruta.substring("/comprar/".length());
        String consulta = intercambio.getRequestURI().getQuery();
        int cantidad = 1;
        if (consulta != null) {
            cantidad = Integer.parseInt(consulta.split("=")[1]);
        }

        Producto p = catalogo.buscar(nombre);
        if (p == null) {
            String contenido = "<h1>Lo sentimos</h1><p>No tenemos " + nombre + "</p>";
            EnvioHttp.enviarHtml(intercambio, 404, Plantilla.pagina("No encontrado", contenido));
        }else if (!pedidos.cantidadValida(cantidad)) {
            String contenido = "<h1>Cantidad no válida </h1><p> Sólo puedes pedir entre 1 y 10 unidades </p>";
            EnvioHttp.enviarHtml(intercambio, 400, Plantilla.pagina("Cantidad no válida", contenido));
    //control stock
        }else if (!pedidos.hayStock(p, cantidad)){
            String contenido = "<h1> No hay suficientes Unidades </h1> <p> Solo quedan "
                    +p.getStock() + "unidades de " +p.getNombre()+ "</p>";
            EnvioHttp.enviarHtml(intercambio, 409,Plantilla.pagina("Sin suficiente Stock", contenido));
        }else{
            ResumenPedido r = pedidos.calcular(p,cantidad);
            String envio = Plantilla.euros(r.getGastosEnvio());
            if(r.getGastosEnvio()==0)
            {
                envio = "¡GRATIS!";
            }
            String contenido = "<h1> Resumen de tu pedido </h1>"
                    +"<p>" +r.getCantidad() + " x " +r.getProducto()
                    +" a " +Plantilla.euros(r.getPrecioUnidad())+ "</p>"
                    +"<p>Subtotal: " +Plantilla.euros(r.getSubtotal())+ "</p>"
                    +"<p>Gastos de envío: " +envio+ "</p>"
                    +"<p><b> Total: " +Plantilla.euros(r.getTotal())+ "</b></p>";

            EnvioHttp.enviarHtml(intercambio, 200, Plantilla.pagina("Resumen del pedido ", contenido));
        }
    }












}



































