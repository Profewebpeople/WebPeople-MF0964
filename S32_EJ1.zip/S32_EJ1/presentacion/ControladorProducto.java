package S32_EJ1.presentacion;

import S32_EJ1.negocio.ServicioPedido;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import S32_EJ1.modelo.Producto;
import S32_EJ1.negocio.ServicioCatalogo;
import java.io.IOException;

public class ControladorProducto implements HttpHandler {
    private ServicioCatalogo servicio;
    private ServicioPedido pedidos;

    public ControladorProducto(ServicioCatalogo servicio, ServicioPedido pedidos) {
        this.servicio = servicio;
        this.pedidos = pedidos;
    }


    @Override
    public void handle(HttpExchange intercambio) throws IOException {
        String ruta = intercambio.getRequestURI().getPath();
        String nombre = ruta.substring("/producto/".length());
        Producto p = servicio.buscar(nombre);

        if (p != null) {
            String contenido = "<h1>" + p.getNombre() + "</h1>"
                    + "<p>Antes: <s>" + Plantilla.euros(p.getPrecio()) + "</s></p>"
                    + "<p>Black Friday: <b>" + Plantilla.euros(servicio.precioFinal(p)) + "</b></p>";
            if (!pedidos.disponible(p)) {
                contenido += "<p><b>AGOTADO</b></p>";
            } else {
                if (pedidos.ultimasUnidades(p)) {
                    contenido += "<p><b>ULTIMAS UNIDADES!! quedan: " + p.getStock() + " . </b></p>";
                }
                contenido += "<form action=\"/comprar/" + p.getNombre() + "\">" //ruta del formulario cuando le de al boton "comprar" abre la pagina /comprar/producto
                        + "Cantidad: <input name=\"cantidad\" value=\"1\">" + //espacio para poner la cantidad
                        "<button>Comprar</button></form>"; // botón de la acción de comprar
            }
            EnvioHttp.enviarHtml(intercambio, 200, Plantilla.pagina(p.getNombre(), contenido));
        }else{
            String contenido = "<h1> Lo sentimos </h1><p> No tenemos " + nombre + "</p>";
            EnvioHttp.enviarHtml(intercambio, 400, Plantilla.pagina("No encontrado",  contenido));
        }


    }
}